const CACHE='gymlog-cache-v1';
const ASSETS=['./','./index.html','./manifest.webmanifest','./icon-192.png','./icon-512.png'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
self.addEventListener('fetch',event=>{
 if(event.request.method!=='GET') return;
 event.respondWith(caches.match(event.request).then(cached=>{
  if(cached) return cached;
  return fetch(event.request).then(response=>{
   if(response && response.ok && new URL(event.request.url).origin===self.location.origin){
    const clone=response.clone(); caches.open(CACHE).then(cache=>cache.put(event.request,clone));
   }
   return response;
  }).catch(()=>caches.match('./index.html'));
 }));
});